# GUI en Python con PyQt5 / PySide2

<div align="center">
  
### Menú Lateral en Python con PySide2 / PyQt5 - Qt Designer

![4](https://github.com/MagnoEfren/gui_python_pyqt5/blob/main/Menu%20Lateral%20desplegable/screenshot.png)
<a href="https://youtu.be/2D05tvP4Gm0" target="_blank">
<img src="https://img.shields.io/badge/YouTube-F7F9F9?style=for-the-badge&logo=youtube&logoColor=black" target="_blank"> 
  
### PyQt5 con Matplotlib | Grafica del Seno Frecuencia y Amplitud QSlider

![4](https://github.com/MagnoEfren/gui_python_pyqt5/blob/main/Grafica%20con%20Matplotlib%20PyQt5/pyqt5-y-matplotlib.png)
<a href="https://youtu.be/XvIAVnpdLYc" target="_blank">
<img src="https://img.shields.io/badge/YouTube-F7F9F9?style=for-the-badge&logo=youtube&logoColor=black" target="_blank"> 
